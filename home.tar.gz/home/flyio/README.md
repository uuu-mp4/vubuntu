# fly-docker

Fly价格介绍 附带项目免费 详情点击下方链接

https://fly.io/docs/pricing/

在github部署 参考下方链接

https://fly.io/docs/app-guides/continuous-deployment-with-github-actions/
