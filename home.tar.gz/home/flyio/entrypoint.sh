#!/bin/sh
#ssh
#service ssh restart
mkdir /tmp/v2ray
#curl -L -H "Cache-Control: no-cache" -o /tmp/v2ray/v2ray.zip https://github.com/v2fly/v2ray-core/releases/latest/download/v2ray-linux-64.zip
curl -L -H "Cache-Control: no-cache" -o /tmp/v2ray/xray.zip https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64.zip
unzip /tmp/v2ray/xray.zip -d /tmp/v2ray
mv /tmp/v2ray/xray /tmp/v2ray/xy
install -m 755 /tmp/v2ray/xy /usr/local/bin/xy
install -m 644 /tmp/v2ray/geoip.dat  /usr/local/bin/geoip.dat
install -m 644 /tmp/v2ray/geosite.dat  /usr/local/bin/geosite.dat

# Remove temporary directory
rm -rf /tmp/v2ray

# V2Ray new configuration
install -d /usr/local/etc/v2ray
cat <<-EOF > /usr/local/etc/v2ray/config.json
{
    "log": {
    "loglevel": "warning"
    },
    "inbounds": [{
          "port": 54321,
          "listen": "127.0.0.1",
          "protocol": "vmess",
          "settings": {
                "clients": [{
                      "id": "fa0d9aeb-df52-4466-a2e9-5203c091f3c0",
                      "alterId": 64
                }]
          },
          "streamSettings": {
                "network": "ws",
                "wsSettings": {
                          "path": "/v2-t"
                }
          }
},
{
          "port": 54322,
          "listen": "127.0.0.1",
          "protocol": "vless",
          "settings": {
                "clients": [{
                     "id": "fa0d9aeb-df52-4466-a2e9-5203c091f3c0",
                     "level": 0,
                     "email": "vless@v2fly.org"
                }],
           "decryption": "none"
           },
           "streamSettings": {
                   "network": "ws",
                   "wsSettings": {
                           "path": "/v2-tl"
                   }
           }
},
{
          "port": 54323,
          "listen": "127.0.0.1",
          "protocol": "trojan",
          "settings": {
                "clients": [{
                     "password": "fa0d9aeb-df52-4466-a2e9-5203c091f3c0",
                     "email": "trojan@v2fly.org"
                }]
           },
           "streamSettings": {
                   "network": "ws",
                   "wsSettings": {
                       "enabled": true,
                       "path": "/v2-tj"
                   }
           }
    }],
"outbounds": [
  {
    "tag":"IPv4_out",
    "protocol": "freedom"
  },
  {
    "tag":"IPv6_out",
    "protocol": "freedom",
    "settings": {
      "domainStrategy": "UseIPv6"
    }
  }
],
"routing": {
  "rules": [
    {
      "type": "field",
      "outboundTag": "IPv6_out",
      "domain": ["geosite:google","geosite:youtube","pronhub.com","geosite:netflix","nflxvideo.net","nflxext.com","nflxso.net"]
    },
    {
      "type": "field",
      "outboundTag": "IPv4_out",
      "network": "udp,tcp"
    }
  ]
}
}
EOF
# Run V2Ray
nohup /usr/local/bin/xy -config /usr/local/etc/v2ray/config.json >v2.txt 2>&1 &

#nohup /linux_amd64/sunny clientid a089fd92ca6ebdc7 >ssh.txt 2>&1 &

#VERSION=$(/usr/local/bin/xy version |grep V |awk '{print $2}')
VERSION=$(/usr/local/bin/xy version)
REBOOTDATE=$(date)
sed -i "s/VERSION/$VERSION/g" /wwwroot/index.html
sed -i "s/REBOOTDATE/$REBOOTDATE/g" /wwwroot/index.html

caddy -conf="/etc/Caddyfile"
