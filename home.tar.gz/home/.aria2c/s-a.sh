#!/bin/bash
aria2c --conf=/home/.aria2c/aria2.conf -D
